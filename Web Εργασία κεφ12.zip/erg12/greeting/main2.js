import greet from "./greeting.js";
 let myGreet = greet("HelloWorld")

 console.log("gt", myGreet)

