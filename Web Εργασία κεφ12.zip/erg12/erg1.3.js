const numbers = [-1, -5, -4, 0, 1, 2, 3, 4, 5];

const doubleNumbers = numbers.some(number => number > 0);
 
console.log(doubleNumbers);