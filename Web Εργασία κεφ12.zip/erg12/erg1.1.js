const numbers = [1, 2, 3, 4, 5];

const doubleNumbers = numbers.map(number => number * 2);
 
console.log(doubleNumbers);
